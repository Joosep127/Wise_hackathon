# Bill splitter — source review bundle

This archive contains the current application source, tests, scripts, dependency manifests and database schema/migrations.

No receipt images, logos, fonts, OCR models, uploaded files, user data, payment records, environment secrets, dependencies, builds, caches, Git history or local runtime databases are included.

The database is intentionally empty: apply drizzle/0000_lean_skaar.sql and drizzle/0001_active_people.sql to a fresh local database using the README commands. These migrations contain schema only, no saved bills or seed data. db/cleanup.sql is a maintenance script, not an initialization migration.

The hosting configuration uses local bindings with no project identifier. Assets are intentionally omitted for this code review, so logo URLs will not resolve; the OCR preparation script can regenerate OCR assets after installing dependencies. Optional Apple Vision source is included; its compiled binary is not.

All payments are demo payments. Test fixtures and sample receipt text are synthetic examples embedded in the source.
